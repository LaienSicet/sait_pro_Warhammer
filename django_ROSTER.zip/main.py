#python manage.py runserver
#python manage.py startapp roster_1
#cd C:\Python\pythonProject\django_ROSTER\roster
#python manage.py makemigrations   python manage.py migrate
#python manage.py createsuperuser

# Kroy    GK
# guest   Grey Knights
