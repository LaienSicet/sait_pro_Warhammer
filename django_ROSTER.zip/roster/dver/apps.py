from django.apps import AppConfig


class DverConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dver'
