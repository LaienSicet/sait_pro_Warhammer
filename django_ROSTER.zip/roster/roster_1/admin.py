from django.contrib import admin
from .models import Ros
# Register your models here.

admin.site.register(Ros)